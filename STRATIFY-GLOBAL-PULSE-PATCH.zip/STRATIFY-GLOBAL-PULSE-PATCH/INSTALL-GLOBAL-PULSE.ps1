param(
    [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$FilesRoot = Join-Path $PatchRoot "files"
$ProjectRoot = (Resolve-Path $ProjectRoot).Path

if (-not (Test-Path (Join-Path $ProjectRoot "package.json"))) {
    throw "package.json was not found in: $ProjectRoot. Run this from the Stratify project root or pass -ProjectRoot."
}

if (-not (Test-Path (Join-Path $ProjectRoot "app"))) {
    throw "The app directory was not found in: $ProjectRoot"
}

$RelativeFiles = @(
    "app\api\_lib\global-pulse\types.ts",
    "app\api\_lib\global-pulse\utils.ts",
    "app\api\_lib\global-pulse\sources.ts",
    "app\api\global-pulse\route.ts",
    "app\global-pulse\page.tsx",
    "app\components\TopNav.tsx",
    "app\components\DataSourceNote.tsx"
)

Write-Host ""
Write-Host "Installing Stratify Global Pulse..." -ForegroundColor Cyan
Write-Host "Project: $ProjectRoot" -ForegroundColor DarkGray
Write-Host ""

foreach ($RelativePath in $RelativeFiles) {
    $Source = Join-Path $FilesRoot $RelativePath
    $Destination = Join-Path $ProjectRoot $RelativePath
    $DestinationDirectory = Split-Path -Parent $Destination

    if (-not (Test-Path $Source)) {
        throw "Patch file is missing: $Source"
    }

    New-Item -ItemType Directory -Path $DestinationDirectory -Force | Out-Null
    Copy-Item -Path $Source -Destination $Destination -Force
    Write-Host "  Applied  $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "Global Pulse patch installed successfully." -ForegroundColor Green
Write-Host ""
Write-Host "No npm package installation is required." -ForegroundColor Yellow
Write-Host ""
Write-Host "Optional ReliefWeb setup:" -ForegroundColor Cyan
Write-Host '  Add RELIEFWEB_APPNAME=<your-approved-appname> to .env.local and Vercel.' -ForegroundColor White
Write-Host "  The other sources work without an API key." -ForegroundColor DarkGray
Write-Host ""
Write-Host "Validate:" -ForegroundColor Cyan
Write-Host "  npm run build" -ForegroundColor White
Write-Host "  npm run dev" -ForegroundColor White
Write-Host "  Open http://localhost:3000/global-pulse" -ForegroundColor White
Write-Host ""
