param(
    [string]$BaseUrl = "http://localhost:3000"
)

$ErrorActionPreference = "Stop"
$Url = "$($BaseUrl.TrimEnd('/'))/api/global-pulse?topic=all&hours=168&limit=20&refresh=1"

Write-Host "Testing: $Url" -ForegroundColor Cyan
$response = Invoke-RestMethod -Uri $Url -Method Get -TimeoutSec 90

$response | Select-Object ok, generatedAt, counts, warnings | ConvertTo-Json -Depth 6

Write-Host ""
Write-Host "Source status:" -ForegroundColor Cyan
$response.sourceStatus |
    Select-Object label, ok, configured, count, error |
    Format-Table -AutoSize
