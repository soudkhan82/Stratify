"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import AuthNavButton from "@/components/AuthNavButton";

const NAV_ITEMS = [
  { label: "Home", href: "/" },
  { label: "Global Pulse", href: "/global-pulse" },
  { label: "Monetary", href: "/monetary" },
  { label: "Fiscal", href: "/fiscal" },
  { label: "Debt", href: "/debt" },
  { label: "Energy", href: "/energy" },
  { label: "FAO", href: "/faostat" },
  { label: "IMF (WEO)", href: "/imf-weo" },
  { label: "History", href: "/history" },
  { label: "Corporate 500", href: "/corporate-intelligence" },
  { label: "Credits", href: "/credits" },
];

const MOBILE_ITEMS = [
  { label: "Home", href: "/" },
  { label: "Pulse", href: "/global-pulse" },
  { label: "Monetary", href: "/monetary" },
  { label: "FAO", href: "/faostat" },
  { label: "History", href: "/history" },
  { label: "IMF", href: "/imf-weo" },
];

function isActivePath(pathname: string, href: string) {
  if (href === "/") return pathname === "/";

  if (href === "/faostat") {
    return (
      pathname === "/faostat" ||
      pathname.startsWith("/faostat/") ||
      pathname.includes("dataset=faostat") ||
      pathname.includes("dataset=fao")
    );
  }

  if (href === "/imf-weo") {
    return (
      pathname === "/imf-weo" ||
      pathname.startsWith("/imf-weo/") ||
      pathname.includes("dataset=weo")
    );
  }

  if (href === "/history") {
    return pathname === "/history" || pathname.startsWith("/history/");
  }

  if (href === "/monetary") {
    return pathname === "/monetary" || pathname.startsWith("/monetary/");
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

function MobileNavLink({
  href,
  label,
  pathname,
}: {
  href: string;
  label: string;
  pathname: string;
}) {
  const active = isActivePath(pathname, href);

  return (
    <Link
      href={href}
      className={[
        "shrink-0 rounded-full px-3 py-2 text-xs font-black",
        active
          ? "bg-violet-600 text-white shadow-md shadow-violet-200"
          : "bg-slate-100 text-slate-700",
      ].join(" ")}
    >
      {label}
    </Link>
  );
}

export default function TopNav() {
  const pathname = usePathname() || "/";

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/90 shadow-sm backdrop-blur-xl">
      <div className="mx-auto flex h-[72px] w-full max-w-[1480px] items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex shrink-0 items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-blue-600 text-lg font-black text-white shadow-lg shadow-violet-200">
            S
          </div>

          <div className="hidden leading-tight sm:block">
            <div className="text-lg font-black tracking-tight text-slate-950">
              Stratify
            </div>
            <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400">
              Analytics
            </div>
          </div>
        </Link>

        <div className="ml-auto hidden min-w-0 items-center gap-2 lg:flex">
          <nav className="flex min-w-0 items-center gap-0.5 rounded-full border border-slate-200 bg-slate-50 p-1.5 shadow-sm">
            {NAV_ITEMS.map((item) => {
              const active = isActivePath(pathname, item.href);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={[
                    "whitespace-nowrap rounded-full px-2 py-2 text-[12px] font-bold transition-all xl:px-2.5 xl:text-[13px] 2xl:px-3",
                    active
                      ? "bg-gradient-to-r from-violet-600 to-blue-600 text-white shadow-md shadow-violet-200"
                      : "text-slate-600 hover:bg-white hover:text-slate-950 hover:shadow-sm",
                  ].join(" ")}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <AuthNavButton />
        </div>

        <div className="ml-auto flex min-w-0 flex-1 items-center gap-2 lg:hidden">
          <nav className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {MOBILE_ITEMS.map((item) => (
              <MobileNavLink
                key={item.href}
                href={item.href}
                label={item.label}
                pathname={pathname}
              />
            ))}
          </nav>

          <div className="shrink-0">
            <AuthNavButton />
          </div>
        </div>
      </div>
    </header>
  );
}
