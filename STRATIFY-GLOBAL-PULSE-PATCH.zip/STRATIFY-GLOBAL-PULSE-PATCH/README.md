# Stratify Global Pulse — Drop-in Patch

This patch adds the first Global Pulse release to the current Stratify Next.js App Router project.

## Included

- `/global-pulse` responsive Yahoo-style intelligence page
- `/api/global-pulse` normalized multi-source endpoint
- GDELT global article search
- World Bank official news
- IMF official feed adapter
- WTO official RSS adapter
- FAO Newsroom RSS adapter
- Wikimedia “On This Day” adapter
- Optional ReliefWeb/OCHA API adapter
- Search, country, category and 24-hour/7-day filters
- Deduplication, topic classification, source status and in-memory caching
- Links from stories to relevant Stratify modules
- Updated desktop/mobile navigation and Global Pulse data-source disclosure
- No database migration and no new npm dependency

## Installation

From PowerShell:

```powershell
Set-Location "C:\NextJS\stratify"
& "C:\Path\To\STRATIFY-GLOBAL-PULSE-PATCH\INSTALL-GLOBAL-PULSE.ps1" -ProjectRoot (Get-Location).Path
npm run build
npm run dev
```

Then open:

```text
http://localhost:3000/global-pulse
```

## Optional ReliefWeb setup

ReliefWeb requires an approved `appname`. Add this to local and production environment variables after approval:

```env
RELIEFWEB_APPNAME=your-approved-appname
```

Without it, Global Pulse continues to work with GDELT, World Bank, IMF, WTO, FAO and Wikimedia. The Source Health panel marks ReliefWeb as `SETUP` instead of breaking the page.

## API test

```powershell
& ".\TEST-GLOBAL-PULSE.ps1" -BaseUrl "http://localhost:3000"
```

## Files applied

```text
app/api/_lib/global-pulse/types.ts
app/api/_lib/global-pulse/utils.ts
app/api/_lib/global-pulse/sources.ts
app/api/global-pulse/route.ts
app/global-pulse/page.tsx
app/components/TopNav.tsx
app/components/DataSourceNote.tsx
```

The installer overwrites only the two listed existing navigation/source-note files and creates the new Global Pulse files. It does not create backup files.
